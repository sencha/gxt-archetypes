#GXT Theme Archetype
Build a GXT project with custom theme. 

##Building
First run `mvn install` on the entire project. 

##Building theme.
Run `mvn install` in theme module to build theme.  
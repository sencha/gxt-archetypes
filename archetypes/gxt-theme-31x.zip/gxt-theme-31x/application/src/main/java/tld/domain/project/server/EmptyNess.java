package tld.domain.project.server;

/**
 * Provide something for the archetype generator to chew on so it creates the correct packages.
 */
public class EmptyNess {

}
